'use strict';

import shell from './shell';

shell({
  log: false
});
